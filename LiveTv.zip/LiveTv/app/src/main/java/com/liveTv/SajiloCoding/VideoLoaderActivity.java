package com.liveTv.SajiloCoding;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import com.github.ybq.android.spinkit.*;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class VideoLoaderActivity extends  Activity { 
	
	
	private SpinKitView linear1;
	private VideoView videoview1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.video_loader);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (SpinKitView) findViewById(R.id.linear1);
		videoview1 = (VideoView) findViewById(R.id.videoview1);
		MediaController videoview1_controller = new MediaController(this);
		videoview1.setMediaController(videoview1_controller);
		
		videoview1.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){
			@Override
			public void onPrepared(MediaPlayer _mediaPlayer){
				linear1.setVisibility(View.GONE);
				 Toast.makeText(getApplicationContext(), "Loading..", Toast.LENGTH_SHORT).show();
			}
		});
		
		videoview1.setOnErrorListener(new MediaPlayer.OnErrorListener(){
			@Override
			public boolean onError(MediaPlayer _mediaPlayer, int _what, int _extra){
				linear1.setVisibility(View.GONE);
				 Toast.makeText(getApplicationContext(), "Can't Play this Link..", Toast.LENGTH_SHORT).show();
				return true;
			}
		});
		
		videoview1.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
			@Override
			public void onCompletion(MediaPlayer _mediaPlayer){
				linear1.setVisibility(View.GONE);
				 Toast.makeText(getApplicationContext(), "Video Loaded Successfully..", Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	private void initializeLogic() {
		videoview1.setVideoURI(Uri.parse(getIntent().getStringExtra("url")));
		videoview1.start();
		videoview1.setMediaController(null);
		linear1.setVisibility(View.VISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		videoview1.pause();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		videoview1.start();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
