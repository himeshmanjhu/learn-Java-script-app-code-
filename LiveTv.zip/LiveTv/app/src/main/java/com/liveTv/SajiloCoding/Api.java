package com.liveTv.SajiloCoding;
public class Api
{
public static final String api_key ="https://sabinchaudhary.com.np/LiveTv/tv.json";
}
