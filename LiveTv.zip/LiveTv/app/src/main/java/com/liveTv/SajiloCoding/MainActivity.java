package com.liveTv.SajiloCoding;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.bumptech.glide.Glide;
import com.github.ybq.android.spinkit.*;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MainActivity extends  Activity { 
	
	
	private String str = "";
	
	private ArrayList<HashMap<String, Object>> maplist = new ArrayList<>();
	
	private SpinKitView linear1;
	private GridView gridview1;
	
	private SharedPreferences spf;
	private AlertDialog.Builder internet;
	private Intent intt = new Intent();
	private Intent rate = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (SpinKitView) findViewById(R.id.linear1);
		gridview1 = (GridView) findViewById(R.id.gridview1);
		spf = getSharedPreferences("spf", Activity.MODE_PRIVATE);
		internet = new AlertDialog.Builder(this);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				intt.setClass(getApplicationContext(), VideoLoaderActivity.class);
				intt.putExtra("url", maplist.get((int)_position).get("url").toString());
				startActivity(intt);
			}
		});
	}
	
	private void initializeLogic() {
		internet.setCancelable(false);
		linear1.setVisibility(View.VISIBLE);
		android.net.ConnectivityManager cm = (android.net.ConnectivityManager) this.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);android.net.NetworkInfo activeNetwork = cm.getActiveNetworkInfo();if (activeNetwork != null) {if (activeNetwork.getType() == android.net.ConnectivityManager.TYPE_WIFI) {
				
				
				new BackTask().execute(Api.api_key);
				} else if (activeNetwork.getType() == android.net.ConnectivityManager.TYPE_MOBILE) {

							new BackTask().execute(Api.api_key);}} else {
						
			if (spf.getString("ss", "").equals("")) {
				internet.setTitle("No Internet Found ");
				internet.setMessage("please Check Your Internet Connection");
				internet.setPositiveButton("हुन्छ ।", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				internet.create().show();
				linear1.setVisibility(View.GONE);
			}
			else {
				maplist = new Gson().fromJson(spf.getString("ss", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				linear1.setVisibility(View.GONE);
								Toast.makeText(getApplicationContext(), "Offline", Toast.LENGTH_SHORT).show();
				
				gridview1.setAdapter(new Gridview1Adapter(maplist));
				gridview1.setNumColumns((int)3);
				gridview1.setColumnWidth((int)10);
				gridview1.setVerticalSpacing((int)10);
				gridview1.setHorizontalSpacing((int)10);
				gridview1.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			}
			 
		} 
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		//Code for Creating Action Bar Menu
		//Code By Sajilo Coding
		MenuItem menuitem1 = menu.add(Menu.NONE, 1, Menu.NONE, "Rate App");
		menuitem1.setIcon(R.drawable.rate_icon);
		menuitem1.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		MenuItem menuitem2 = menu.add(Menu.NONE, 2, Menu.NONE, "About Developer");
		menuitem2.setIcon(R.drawable.about_icon);
		menuitem2.setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
		 
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
		public boolean onOptionsItemSelected(MenuItem item){
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
		if (_id == 1) {
			//Intent for Rating Your App
			rate.setAction(Intent.ACTION_VIEW);
			rate.setData(Uri.parse("https://play.google.com/store/apps/details?id=PutYourPackageName"));
			startActivity(rate);
			//End Intent for Rate App
		}
		else {
			if (_id == 2) {
				//This code is for Showing Custom Dialog
				final AlertDialog dialog2 = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.about, null);
				dialog2.setView(inflate);
				dialog2.setCancelable(true);
				dialog2.show();
				//End Code for Dialog 
				 
			}
			else {
				
			}
		}
		return super.onOptionsItemSelected(item);
	}
	public void _extra () {
	}
	
	private class BackTask extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {
			linear1.setVisibility(View.VISIBLE);
			
			
		}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s){
			
			str=s;
			maplist = new Gson().fromJson(str, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			gridview1.setAdapter(new Gridview1Adapter(maplist));
			gridview1.setNumColumns((int)3);
			gridview1.setColumnWidth((int)10);
			gridview1.setVerticalSpacing((int)10);
			gridview1.setHorizontalSpacing((int)10);
			gridview1.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			spf.edit().putString("ss", str).commit();
			linear1.setVisibility(View.GONE);
		}
	}
	
	
	public class Gridview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.grid, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF4CAF50, 0xFFFFFFFF));
			textview1.setText(maplist.get((int)_position).get("title").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(maplist.get((int)_position).get("img").toString())).into(imageview1);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
